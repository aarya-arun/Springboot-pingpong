package com.example1.demo1.kafka;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import javax.servlet.http.HttpServletResponse;

import com.example1.demo1.messages.Messages;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class KafkaProducer {

    private boolean stop = true;

    KafkaConsumer consumer = new KafkaConsumer();
 
    @RequestMapping("/")
    public String homePage(){
        return "Home";
    }

    @Autowired
   	private KafkaTemplate<String, Messages> kafkaTemplate;

    @RequestMapping("/start")
    public String sendMessage(HttpServletResponse response) throws IOException {
        
    
         System.out.println("redirecting your message");
         response.sendRedirect("/consumer");
        return "Redirected";
    }
    
       
       
}
