fmpackage com.example1.demo1.kafka;

import java.util.concurrent.TimeUnit;

import com.example1.demo1.messages.Messages;
import com.example1.demo1.sql.Model.MessagesTable;
import com.example1.demo1.sql.Repo.MessageRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@Service
public class KafkaConsumer {

    public boolean sending_msg = true;


    @Autowired
    MessageRepository repo;

    @Autowired
    private KafkaTemplate<String, Messages> k_template;

    @KafkaListener(topics = "microservice2", groupId = "group2", containerFactory = "kafkaListenerFactory2")
    public void consumerJson(Messages msg) {

        System.out.println("Mssage: " + msg.getMessage());
        String str1 = msg.getMessage();
        String str2 = "Begin";
        if(str1.equals(str2)){ 
            System.out.println("Sending message");
            sending_msg = true;
        } 
        repo.save(new MessagesTable(msg.getMessage()));

        System.out.println("Added message to the database");
        
        if (sendMessage) { 
            try {
                TimeUnit.SECONDS.sleep(5);
            } catch (InterruptedException exception_1) {
               
                exception_1.printStackTrace();
            }
            k_template.send("microservice1", new Messages(0, "Hi from microservice2"));
        }
        
    }

    @RequestMapping("/stop") 
    public String setSendMessage(){
        sending_msg = false;
        
        return "Stopped.";
    }

    @RequestMapping("/consumer") 
    public String updateSendMessage(){
        sending_msg = true;
        System.out.println("redirecting");
        kafkaTemplate.send("microservice1", new Messages(0, "Begin"));
        return "ping-pong has begun";
    }
}
