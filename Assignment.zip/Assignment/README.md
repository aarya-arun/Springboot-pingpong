Use gradle to run demo and demo1

To start the ping pong: /start 
To stop the ping pong: /stop 
  

Create 2 postgres db instances on ports 5434 and 5433
5433: DB - 'microservice1'
      table - 'messages'
      role - 'microservice1'
      password for role - 'password'
      The role should have access to the message table

5434: DB - 'microservice'2
      table - 'messages'
      role - 'user2'
      password for role - 'pwd2'
      The role should have access to the message table
