package com.example.demo.kafka;

import java.util.concurrent.TimeUnit;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.example.demo.messages.Messages;
import com.example.demo.sql.Model.MessagesTable;
import com.example.demo.sql.Repo.MessageRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;

@RestController
@Service
public class KafkaConsumer {

    public boolean sending_msg = true;

    @Autowired
    MessageRepository repo;
    
    @Autowired
    private KafkaTemplate<String, Messages> k_template;

    @KafkaListener(topics = "microservice1", groupId = "group1", containerFactory = "kafkaListenerFactory")
    public void consumerJson(Messages msg) {
        System.out.println("Message: " + msg.getMessage());
        String str1 = msg.getMessage();
        String str2 = "Begin";
        if(str1.equals(str2)){ 
            sending_msg = true;
        } 
        repo.save(new MessagesTable(msg.getMessage()));

        System.out.println("Message added.");

        if (sending_msg) { 
            try {
                TimeUnit.SECONDS.sleep(5);
            } catch (InterruptedException exception1) {
               
                exception1.printStackTrace();
            }
            k_template.send("microservice2", new Messages(0, "message from first microservice"));
        }
        
    }

    @RequestMapping("/stop") 
    public String setsendmsg(){
        sending_msg = false;
        return "Stopped ping pong!";
    }

    @RequestMapping("/consumer") 
    public String updatesendmsg(){
        sending_msg = true;
        k_template.send("microservice2", new Messages(0, "start"));
        return "Started Ping Pong!";
    }
}
