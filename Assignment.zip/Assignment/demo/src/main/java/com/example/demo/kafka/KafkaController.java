package com.example.demo.kafka;

import java.io.IOException;
import javax.servlet.http.HttpServletResponse;
import com.example.demo.messages.Messages;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;


@RestController
public class KafkaController {


    @RequestMapping("/")
    public String homePage() {
        return "Home";
    }

    @Autowired
    private KafkaTemplate<String, Messages> kafkaTemplate;

    @RequestMapping("/start") //Redirect the request to KafkaConsumer to activate the loop
    public String sendMessage(HttpServletResponse response) throws IOException {
    
        System.out.println("Redirecting your request");
        response.sendRedirect("/consumer");
        return "Request has been redirected";
    }
    
    
}
