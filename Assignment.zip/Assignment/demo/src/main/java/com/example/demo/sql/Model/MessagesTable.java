package com.example.demo.sql.Model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "messages")
public class MessagesTable implements Serializable {

    private static final long serialVersionUID = 5751388729435074607L;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;
    
    @Column(name = "message")
    private String message;

    public long getId() {
        return this.id;
    }

    public messagesTable(){}


    public messagesTable(String msg) {
        this.msg = msg;
    }

    public void setMessage(String msg) {


    public String getMessage() {
        return this.msg;
    }

        this.msg = msg;
    }

}
