package com.example.demo.messages;

public class Messages {
    
    private int id;
    private String msg;

    public Messages(){}

    public Messages(int id, String msg) {
        this.id = id;
        this.msg = msg;
    }

    
    public int getId() {
        return this.id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String get_message() {
        return this.msg;
    }

    public void setMessage(String msg) {
        this.msg = msg;
    }



    @Override
    public String toString() {
        return "{" +
            " id='" + getId() + "'" +
            ", msg='" + getMessage() + "'" +
            "}";
    }
    
    
}
